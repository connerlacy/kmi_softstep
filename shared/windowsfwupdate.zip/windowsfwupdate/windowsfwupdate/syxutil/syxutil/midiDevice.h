#include "windows.h"

int getDeviceInIndex(char *name,int *index);
void send_sysex(FILE *fd,int deviceIndex);

