// syxutil.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <windows.h>
//#include <winBase.h>
#include <direct.h>
#include "midiDevice.h"
#include <string.h>

#define MAX_WD_LEN	1000

char workingDirectory[MAX_WD_LEN];
char workingDirectoryTemp[MAX_WD_LEN];

FILE *open_sysex(char *sysexFilePath)
{
	FILE *fd = 0;

	//fd = fopen(sysexFilePath,"rb");
	fopen_s(&fd, sysexFilePath, "rb");

	if (fd)
	{
		printf("\nSoftStep.syx found.\n");
		return fd;
	}
	else
	{
		printf("\nSoftStep.syx NOT found.\n");
		return 0;
	}

	return fd;
}


int _tmain(int argc, _TCHAR* argv[])
{
	OSVERSIONINFO osvi;

	ZeroMemory(&osvi, sizeof(OSVERSIONINFO));
	osvi.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);

	GetVersionEx(&osvi);

	int len = GetModuleFileName( NULL, workingDirectory, MAX_WD_LEN );
	
	//Scroll through full path minus 'FirmwareUpdater.exe'
	for(unsigned int i = 0; i < len - 19; i++)
	{
		//Set original workingDirectory to new, shortened path with no .exe
		workingDirectoryTemp[i] = workingDirectory[i];
		//printf("%d\n", i);
	}

	//Append "SoftStep.syx" to workingDirectory
	sprintf_s(workingDirectory,"%s\%s",workingDirectoryTemp,"SoftStep.syx");

	printf("\n-----\n");
	//printf("working directory %s", workingDirectory);
	//printf("\n-----\n");

	FILE *fd = 0;
	int deviceIndex = -1;

	if (!fd)
	{
		printf("\nTrying to open sysex...\n");
		fd = open_sysex(workingDirectory);
	}

	if (deviceIndex<0)
	{
		if(osvi.dwMajorVersion == 5)
		{
			printf("\nWindows Version: XP - Server 2003 R2.\n\n\nSending Firmware to \"USB Audio Device\"...\n");
			getDeviceInIndex("USB Audio Device",&deviceIndex);
		}
		else if(osvi.dwMajorVersion > 5)
		{
			printf("\nWindows Version: Vista or later.\n\nSending Firmware to \"SSCOM\"...\n");
			getDeviceInIndex("SSCOM",&deviceIndex);
		}
	}


	if (!fd)
	{
		printf("\nCould not open sysex file.\n");
	}

	if (deviceIndex < 0)
	{
		printf("\nCould not open midi device.\n");
		//printf(workingDirectory);
	}

	if (!fd || deviceIndex < 0)
	{
		//No sysex file found or device.
		//return 0;
	}

	//Send the firmware to the board
	send_sysex(fd,deviceIndex);

	//While loop to keep console window open...
	while(1)
	{
	}
	
	return 0;
}

