#include "stdafx.h"
#include "midiDevice.h"

int getDeviceInIndex(char *name,int *index)
{
	MIDIOUTCAPS midiOutCaps;
	int i,numDevices = midiOutGetNumDevs();
	for (i=0;i<numDevices;i++)
	{
		if (midiOutGetDevCaps(i,&midiOutCaps,sizeof(midiOutCaps))==MMSYSERR_NOERROR)
		{
			if (!_stricmp(name,(const char *)midiOutCaps.szPname))
			{
//printf("midi in device index[%d]\n",i);
				*index = i;
				return 1;
			}
		}

	}
	return 0;
}
void CALLBACK MidiOutProc(HMIDIOUT hmo,UINT wMsg,DWORD_PTR dwInstance,DWORD_PTR dwParam1,DWORD_PTR dwParam2)
{
	UINT err;
	HGLOBAL herr;
//	PI *po = (PI *) dwInstance;

////	post("MidiOutProc2");

	switch(wMsg)
	{
		case MM_MOM_OPEN:
////			post("MM_MOM_OPEN");
			break;
		case MOM_CLOSE:  // device close
////			post("callback MOM_CLOSE device close");
			break;
		case MOM_DONE:	// sysex completed
////			post("MOM_DONE");
//			if (po->e)
//				err = midiOutUnprepareHeader(po->e->handleOut,  &po->sysexMidiHdr, sizeof(MIDIHDR));

////			if (po->sysexIndex<po->sysexLen)
////				clock_delay(po->sysexTimer,1000);
////				sysexSendNextChunk(po);
//			else {
//				clock_delay(po->sysexCompleteTimer,0);

//		        err = GlobalUnlock(po->sysexhBuffer);
////			post("MOM_DONE GlobalUnlock[%d]",err);
//				herr = GlobalFree(po->sysexhBuffer);
////			post("MOM_DONE GlobalFree[%p]",herr);
////			post("MOM_DONE unprepare[%d]",err);
//			}
			break;
		default:
////			post("MidiOutProc2[%d]",wMsg);
			break;
	}
}

void send_sysex(FILE *fd,int deviceIndex)
{
	HANDLE sysexhBuffer;
	fseek (fd, 0, SEEK_END);   // non-portable
	long int sysexLen = ftell(fd);
	fseek(fd,0,SEEK_SET);
	MIDIHDR     sysexMidiHdr;
	HMIDIOUT handleOut;

	int err = midiOutOpen(&handleOut,deviceIndex,(DWORD_PTR) MidiOutProc,0,CALLBACK_FUNCTION);

	sysexhBuffer = GlobalAlloc(GHND, sysexLen);
	if (sysexhBuffer)
	{

		sysexMidiHdr.lpData = (LPSTR)GlobalLock(sysexhBuffer);  // was LPBYTE

		sysexMidiHdr.dwBufferLength = sysexLen;
		sysexMidiHdr.dwFlags = 0;
		int err = midiOutPrepareHeader(handleOut,  &sysexMidiHdr, sizeof(MIDIHDR));
		if (err)
			return;

		int readCount = fread(sysexMidiHdr.lpData,1,sysexLen,fd);
		if (readCount != sysexLen)
			return;

		err = midiOutLongMsg(handleOut, &sysexMidiHdr, sizeof(MIDIHDR));

		if (err)
		{
			char   errMsg[120];
			//midiOutGetErrorText(err, &errMsg[0], sizeof(errMsg));
			printf("\nMidi Error: %s\n", &errMsg[0]);
		} else
		{
			printf("\nFirmware sent.\n");
		}

	}
}
