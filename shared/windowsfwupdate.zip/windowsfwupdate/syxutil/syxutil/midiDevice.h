#include <windows.h>
#include <mmsystem.h>
//#include <iostream.h>

int getDeviceInIndex(char *name,int *index);
void send_sysex(FILE *fd,int deviceIndex);

