// syxutildemo.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <windows.h>
#include <direct.h>


#define MAX_WD_LEN	2000

int _tmain(int argc, _TCHAR* argv[])
{
	STARTUPINFO          si = { sizeof(si) };
	PROCESS_INFORMATION  pi;
	char                 szExe[] = "syxutil.exe Softstep.syx SSCOM";

	char workingDirectory[MAX_WD_LEN];
	_getcwd(workingDirectory,MAX_WD_LEN);
	printf("Current working directory: %s\n",workingDirectory);

#ifdef USE_SYSTEM
	//	system("syxutil softstep.syx SSCOM");
//		Sleep(10000);
#else
 
	if(CreateProcess(0, szExe, 0, 0, FALSE, 0, 0, 0, &si, &pi))
	{
		long tick_start = GetTickCount();

		Sleep(1000);
		if (!TerminateProcess(pi.hProcess, 0))
		{
			char buf[256];
			FormatMessage(FORMAT_MESSAGE_FROM_SYSTEM, NULL, GetLastError(),MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), buf, 256, NULL);
			printf("error: %s\n",buf);
		}

		WaitForSingleObject(pi.hProcess, INFINITE);  // don't need to wait, but will to find out how long it takes

		tick_start = GetTickCount() - tick_start;
		printf("Elapsed seconds = %ld\n",tick_start/1000);

		CloseHandle(pi.hProcess);
		CloseHandle(pi.hThread);
	}
#endif

	printf("Hit CR to quit\n");
	getchar();

	
	return 0;
}

